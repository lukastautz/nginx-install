<?php
ini_set('display_errors','on');
if(!function_exists('http_response_code')){function http_response_code($code=null){if($code!=null){$code=intval($code);switch($code){case 100:$text='Continue';break;case 101:$text='Switching Protocols';break;case 200:$text='OK';break;case 201:$text='Created';break;case 202:$text='Accepted';break;case 203:$text='Non-Authoritative Information';break;case 204:$text='No Content';break;case 205:$text='Reset Content';break;case 206:$text='Partial Content';break;case 300:$text='Multiple Choices';break;case 301:$text='Moved Permanently';break;case 302:$text='Moved Temporarily';break;case 303:$text='See Other';break;case 304:$text='Not Modified';break;case 305:$text='Use Proxy';break;case 400:$text='Bad Request';break;case 401:$text='Unauthorized';break;case 402:$text='Payment Required';break;case 403:$text='Forbidden';break;case 404:$text='Not Found';break;case 405:$text='Method Not Allowed';break;case 406:$text='Not Acceptable';break;case 407:$text='Proxy Authentication Required';break;case 408:$text='Request Time-out';break;case 409:$text='Conflict';break;case 410:$text='Gone';break;case 411:$text='Length Required';break;case 412:$text='Precondition Failed';break;case 413:$text='Request Entity Too Large';break;case 414:$text='Request-URI Too Large';break;case 415:$text='Unsupported Media Type';break;case 500:$text='Internal Server Error';break;case 501:$text='Not Implemented';break;case 502:$text='Bad Gateway';break;case 503:$text='Service Unavailable';break;case 504:$text='Gateway Time-out';break;case 505:$text='HTTP Version not supported';break;default:$code=500;$text='Internal Server Error';break;}if(isset($_SERVER['SERVER_PROTOCOL'])){$protocol=$_SERVER['SERVER_PROTOCOL'];}else{$protocol='HTTP/1.0';}header($protocol.' '.$code.' '.$text);$return=true;}else{if(isset($GLOBALS['http_response_code'])){$return=$GLOBALS['http_response_code'];}else{$return=200;}}return $return;}}class WebServer{private int $statusCode=200;private string $contentType='text/html; charset=UTF-8';public function __construct(int $statusCode=200){ob_start();$this->statusCode=$statusCode;header_remove('Content-Type');header_remove('content-type');}public function set_status_code(int $statusCode){$this->statusCode=$statusCode;}public function flush(){http_response_code($this->statusCode);header('Content-Type:'.$this->contentType);ob_end_flush();}public function redirect_to(string $url){ob_end_clean();header('Location: '.$url);}public function set_content_type(string $contentType='HTML'){switch(strtolower($contentType)){case 'html':$contentType='text/html; charset=UTF-8';break;case 'javascript':$contentType='text/javascript; charset=UTF-8';break;case 'js':$contentType='text/javascript; charset=UTF-8';break;case 'css':$contentType='text/javascript; charset=UTF-8';break;case 'txt':$contentType='text/plain; charset=UTF-8';break;case 'text':$contentType='text/plain; charset=UTF-8';break;case 'zip':$contentType='application/zip; charset=UTF-8';break;case 'pdf':$contentType='application/pdf; charset=UTF-8';break;case 'xml':$contentType='text/xml; charset=UTF-8';break;case 'default':$contentType='text/html; charset=UTF-8';break;case 'json':$contentType='application/json; charset=UTF-8';break;case 'mp4':$contentType='video/mp4; charset=UTF-8';break;case 'mp3':$contentType='audio/mpeg; charset=UTF-8';break;case 'wav':$contentType='audio/wav; charset=UTF-8';break;case 'bmp':$contentType='image/bmp; charset=UTF-8';break;case 'gif':$contentType='image/gif; charset=UTF-8';break;case 'ief':$contentType='image/ief; charset=UTF-8';break;case 'jpg':$contentType='image/jpeg; charset=UTF-8';break;case 'png':$contentType='image/png; charset=UTF-8';break;case 'jpeg':$contentType='image/jpeg; charset=UTF-8';break;case 'svg':$contentType='image/svg+xml; charset=UTF-8';break;case 'tiff':$contentType='image/tiff;audio/wav; charset=UTF-8';break;case 'ico':$contentType='image/x-icon; charset=UTF-8';break;case 'icon':$contentType='image/x-icon; charset=UTF-8';break;case 'ogg':$contentType='video/ogg; charset=UTF-8';break;case 'quicktime':$contentType='video/quicktime; charset=UTF-8';break;case 'webm':$contentType='video/webm; charset=UTF-8';break;case 'avi':$contentType='video/x-msvideo; charset=UTF-8';break;default:$contentType=$contentType;}$this->contentType=$contentType;}public function get_headers(){return headers_list();}public function header(string $name,string $value,string $splitSymbol=': '){return header($name.$splitSymbol.$value);}public function raw_header(string $rawHeader){return header($rawHeader);}public function remove_header(string $header){header_remove($header);}public function no_cache(){header_remove('Cache-Control');header_remove('cache-control');header_remove('expires');header_remove('Expires');header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');}public function set_cache(int $cacheSeconds){header_remove('Cache-Control');header_remove('cache-control');return header('Cache-Control: max-age='.strval($cacheSeconds));}}class Random{private function randomInt(int $min,int $max){if(function_exists('mt_rand')){return mt_rand($min,$max);}else{return rand($min,$max);}}private function random_int(int $min,int $max){if(function_exists('mt_rand')){return mt_rand($min,$max);}else{return rand($min,$max);}}public function int(int $min,int $max){return $this->randomInt($min,$max);}public function string(int $length=10,string $alphabet='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'){$alphabetLength=strlen($alphabet);$return='';for($step=0;$step<=$length-1;$step++){$return.=$alphabet[$this->randomInt(0,$alphabetLength-1)];}return $return;}}class Session{private?string $id=null;private int $minLength=50;public string $cookieName='session';public int $sessionIdLength=150;public function __construct(string $cookieName='session',int $sessionIdLength=150){$this->cookieName=$cookieName;if($sessionIdLength>$this->minLength){$this->sessionIdLength=$sessionIdLength;}else{$this->sessionIdLength=$this->minLength;}$newCookie=false;session_name($this->cookieName);session_set_cookie_params(['httponly'=>true,'secure'=>true,'samesite'=>'Strict']);session_set_cookie_params(strtotime('+1 month',time())-time(),'/');if(!isset($_COOKIE[$this->cookieName])){$this->id=$this->getNewId();session_id($this->id);session_start();$_SESSION['sessionCookieCheckAge']=time();$newCookie=true;}else{session_start();if(!isset($_SESSION['sessionCookieCheckAge'])){session_destroy();session_name($this->cookieName);session_set_cookie_params(['httponly'=>true,'secure'=>true,'samesite'=>'Strict']);session_set_cookie_params(strtotime('+1 month',time())-time(),'/');$this->id=$this->getNewId();session_id($this->id);session_start();$_SESSION['sessionCookieCheckAge']=time();$newCookie=true;}}if($newCookie==false){$this->id=$_COOKIE[$this->cookieName];if($this->getAge()>1440){$this->newId();}}}public function getAge(){return(time()-$_SESSION['sessionCookieCheckAge'])/60;}public function destroy(){session_destroy();}public function getId(){return $this->id;}public function newId(){$oldSessionData=$_SESSION;$this->destroy();session_name($this->cookieName);session_set_cookie_params(['httponly'=>true,'secure'=>true,'samesite'=>'Strict']);session_set_cookie_params(strtotime('+1 month',time())-time(),'/');$this->id=$this->getNewId();session_id($this->id);session_start();$_SESSION=$oldSessionData;$_SESSION['sessionCookieCheckAge']=time();}private function getNewId(){$maxLength=$this->sessionIdLength;$Random=new Random();$RandomString=$Random->string($maxLength,'abcdefghijklmnopqrstuvwxyz1234567890-');if(function_exists('session_create_id')){$collisionFreeId=session_create_id();$collisionFreeId=strtolower($collisionFreeId);$collisionFreeId=str_replace(',','',$collisionFreeId);}else{$collisionFreeId='';}$id=$collisionFreeId.$RandomString;return substr($id,0,$maxLength);}public function get_age(){return $this->getAge();}public function get_id(){return $this->id;}public function new_id(){return $this->newId();}private function get_new_id(){return $this->getNewId();}public function close(){session_write_close();}}if(!function_exists('sha512')){function sha512(string $password){return hash('sha512',$password);}}if(!function_exists('sha_512')){function sha_512(string $password){return hash('sha512',$password);}}
exec('hostname -I', $ip);
$_SERVER['mngr_ip'] = str_replace(' ', '', $ip[0]);
$_SERVER['mngr_root'] = 'https://' . $_SERVER['mngr_ip'];
$_SERVER['mngr_title'] = 'siteMngr';
if (!file_exists('settings.smngr'))
{
    file_put_contents('settings.smngr', '{"users":{"root":"' . sha512('root') . '"},"color":"black","corner":false,"lang":"en"}');
    $_SERVER['mngr_users'] = ['root' => sha512('root')];
    $_SERVER['mngr_lang'] = 'en';
}
else
{
    $json = json_decode(file_get_contents('settings.smngr'), true);
    $_SERVER['mngr_users'] = $json['users'];
    $_SERVER['mngr_lang'] = $json['lang'];
}
$web_server = new WebServer();
$session = new Session();
if (isset($_SESSION['user']) && isset($_SERVER['mngr_users'][$_SESSION['user']]) && $_SERVER['mngr_users'][$_SESSION['user']] == $_SESSION['password_hash'])
{
	if ($_GET['action'] == 'getload')
	{
		$cpu_load_raw = sys_getloadavg();
		$core_num = trim(shell_exec("grep -P '^physical id' /proc/cpuinfo|wc -l"));
		$cpu_load = $cpu_load_raw[0] / $core_num;
		if ($cpu_load < 0.01)
		{
			$cpu_load = 0.01;
		}
		$cpu_load = round($cpu_load * 100);
		exec('free -m', $ram_raw_data);
		$ram = $ram_raw_data[1];
		$ram = str_replace('  ', ' ', $ram);
		$ram = str_replace('  ', ' ', $ram);
		$ram = str_replace('  ', ' ', $ram);
		$ram = str_replace('  ', ' ', $ram);
		$ram = str_replace('  ', ' ', $ram);
		$ram = explode(' ', $ram);
		$free_ram = $ram[3];
		$total_ram = $ram[1];
		$used_ram = $total_ram - $free_ram;
		$ram_load = round(($used_ram / $total_ram) * 100);
		echo $cpu_load . ';' . $ram_load;
	}
	elseif ($_GET['action'] == 'logout')
	{
		$session -> destroy();
		$web_server -> redirect_to($_SERVER['mngr_root']);
	}
	elseif ($_GET['action'] == 'rc')
	{
		$json['corner'] = $_GET['data'];
		print_r($json);
		file_put_contents('settings.smngr',json_encode($json));
		echo 'true';
		$web_server->flush();
	}
	elseif ($_GET['action'] == 'design')
	{
		$json['color'] = $_GET['data'];
		print_r($json);
		file_put_contents('settings.smngr',json_encode($json));
		echo 'true';
		$web_server->flush();
	}
	//... elseif ()
	else
	{
		echo 'false';
	}
}
else
{
	$web_server -> set_status_code(403);
	echo 'Forbidden';
	$web_server -> flush();
}